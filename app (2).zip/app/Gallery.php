<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gallery extends Model
{
    //
    protected $table ='gallery';
    // protected $table = "gallery";
    // public function project_gallery(){
    //     return $this->BelongsToMany('App\Projects');
    // }
}

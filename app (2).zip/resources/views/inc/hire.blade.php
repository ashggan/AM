<div class="col-md-2 d-flex justify-content-center align-items-center mt-5"> 
        <div class="hireme">
            <p><a href="/contact">Hire me</a> </p>
            <div class="sm"><a href="mailto:ashganwiki@gmail.com"><i class="fa fa-envelope"></i></a></div>
            {{-- <div class="sm"><i class="fa fa-envelope"></i></div> --}}
            <div class="sm"><a href="https://github.com/ashggan" target="_blank"><i class="fa fa-github"></i></a></div>
            <div class="sm"><a href="https://www.linkedin.com/in/ashgan-mustapha-66b56998/" target="_blank"><i class="fa fa-linkedin"></i></a></div>
        </div> 
    </div>
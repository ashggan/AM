@extends('layouts.new')
@section('content')

<section id="portfilio">
<div class="container mt-2">
    <div class="row about justify-content-start align-items-start "> 
        {{-- @include('inc.hire') --}}
             <div class="col-md-11">       
                 <div class="row mb-5">
                    <p>Iam self-taught web developer/programmer with over four years of experience in full stack development and interest in data-driven web apps. Collaborative communicator able to gather and translate customer requirements into technical terms and work effectively in team environments. Quick learner proficient in many web technologies and always keep up to date with latest technologies to deliver optimal solutions. Critical and analytical thinker adept at solving complex technical problems and creating practical IT solutions using web technologies. Experience in planning and delivering software platforms across multiple products and organizational units.</p>     
                 </div>
                
            </div>            
     </div>
</div>
</section>
@endsection
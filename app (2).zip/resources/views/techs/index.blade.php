@extends('layouts.app')

@section('content')
    <techs></techs>
    
@endsection

@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mt-5">
        <div class="col-md-8"><h2>project</h2></div>
    </div>
    
    <item-list></item-list>
  

</div>
@endsection